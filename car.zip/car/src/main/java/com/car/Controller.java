package com.car;

import java.awt.Point;
import java.util.regex.Pattern;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controller {
	/**
	 * getLocation
	 * @param xPos
	 * @param yPos
	 * @param direction
	 * @return
	 */
	@GetMapping(value = "/getCarPosition", produces = MediaType.TEXT_PLAIN_VALUE)
	public ResponseEntity<String>getLocation(@RequestParam(name = "x", required = true) int xPos,
			@RequestParam(name = "y", required = true) int yPos,
			@RequestParam(name = "direction", required = true) String direction) {
		
		if( !Pattern.matches("[rlfRLF]*?", direction)) {
			return new ResponseEntity<>("Incorrect Parameters",HttpStatus.BAD_REQUEST);
		}
		
		if(!direction.toUpperCase().contains("F")) {
			return new ResponseEntity<>(xPos+","+yPos,HttpStatus.OK);
		}
		Point location = new Point(xPos, yPos);
		location = CarUtil.getPointCoordinates(location, direction);
		return new ResponseEntity<>(location.x+","+location.y,HttpStatus.OK);
	}
}
