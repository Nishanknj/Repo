package com.car;

import java.awt.Point;

public class CarUtil {
	/**
	 * getPointCoordinates
	 * 
	 * @param p
	 * @param direction
	 * @return
	 */
	public static Point getPointCoordinates(Point p, String direction) {
		char facing = 'N';
		char[] chars = direction.toUpperCase().toCharArray();
		for (char dir : chars) {
			if (dir == 'F') {
				switch (facing) {
				case 'N':
					p.y = p.y + 1;
					break;
				case 'E':
					p.x = p.x + 1;
					break;
				case 'S':
					p.y = p.y - 1;
					break;
				case 'W':
					p.x = p.x - 1;
					break;
				default:
					break;
				}
			} else {
				if (facing == 'N' && dir == 'R') {
					facing = 'E';
					continue;
				} else if (facing == 'N' && dir == 'L') {
					facing = 'W';
					continue;
				}
				if (facing == 'E' && dir == 'R') {
					facing = 'S';
					continue;
				} else if (facing == 'E' && dir == 'L') {
					facing = 'N';
					continue;
				}
				if (facing == 'S' && dir == 'R') {
					facing = 'W';
					continue;
				} else if (facing == 'S' && dir == 'L') {
					facing = 'E';
					continue;
				}
				if (facing == 'W' && dir == 'R') {
					facing = 'N';
					continue;
				} else if (facing == 'W' && dir == 'L') {
					facing = 'S';
					continue;
				}
			}
		}
		return p;
	}
}
